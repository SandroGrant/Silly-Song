//
//  ViewController.swift
//  Silly Song
//
//  Created by Sandro  on 04/03/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var lyricsView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func reset(_ sender: Any) {
        nameField.text = ""
        lyricsView.text = ""
    }
    
    @IBAction func done(_ sender: Any) {
        (sender as AnyObject).resignFirstResponder()
    }
    
    @IBAction func displayLyrics(_ sender: Any) {
        let fullName = nameField.text!
            
        func ShortNameFromName(name: String)-> String{
        var name = name
            name.remove(at: name.startIndex)
            return name
        }

        _ = ShortNameFromName(name: fullName)

        let lyricsTemplate = [
            "<FULL_NAME>, <FULL_NAME>, Bo B<SHORT_NAME>",
            "Banana Fana Fo F<SHORT_NAME>",
            "Me My Mo M<SHORT_NAME>",
            "<FULL_NAME>"].joined(separator: "\n")

        func lyricsForName(lyricsTemplate: String, fullName: String) -> String {
                
            let shortName = ShortNameFromName(name:fullName)
                
            let lyrics = lyricsTemplate
                .replacingOccurrences(of: "<FULL_NAME>", with: fullName)
                .replacingOccurrences(of: "<SHORT_NAME>", with: shortName)
                
            return lyrics
        }
        lyricsView.text! = lyricsForName(lyricsTemplate: lyricsTemplate, fullName: fullName)
        }
    }
    

